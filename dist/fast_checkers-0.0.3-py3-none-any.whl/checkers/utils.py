from easy_logs import get_logger

logger = get_logger(lvl=10)
