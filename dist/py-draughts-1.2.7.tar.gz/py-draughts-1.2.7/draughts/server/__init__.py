from draughts.server.server import Server
